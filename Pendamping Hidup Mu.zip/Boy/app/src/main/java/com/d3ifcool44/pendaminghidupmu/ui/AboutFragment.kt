package com.d3ifcool44.pendaminghidupmu.ui

import androidx.fragment.app.Fragment
import com.d3ifcool44.pendaminghidupmu.R

class AboutFragment : Fragment(R.layout.fragment_about) {
}