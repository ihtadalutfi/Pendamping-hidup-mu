package com.d3ifcool44.pendaminghidupmu.model

data class HasilPH(
    val total : Float,
    val kategori : KategoriPH
)
