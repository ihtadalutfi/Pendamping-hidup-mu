package com.d3ifcool44.pendaminghidupmu.model

enum class KategoriPH { HEMAT,BOROS
}